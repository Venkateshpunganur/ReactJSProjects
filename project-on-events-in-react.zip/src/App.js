import { useState } from "react";

const App = () => {
  const [bg, setBg] = useState("blue");
  const [v1, setName] = useState("Click Me");

  const fun1 = () => {
    setBg("white");
    setName("One time clicked");
  };

  const fun2 = () => {
    setBg("yellow");
    setName("Double Clicked");
  };

  return (
    <>
      <div className="div1" style={{ backgroundColor: bg }}>
        <button onClick={fun1} onDoubleClick={fun2}>
          {v1}
        </button>
      </div>
    </>
  );
};

export default App;
